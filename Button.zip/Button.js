function myFunction() {
    document.getElementById("demo").innerHTML = "Ohhh! Is that a magic.";
  }